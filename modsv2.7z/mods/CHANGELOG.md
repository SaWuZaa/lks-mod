-   **1.0.2**

    -   Fixed an issue where the track download confirmation text was not displayed in chat.

-   **1.0.1**

    -   Update README.md.

-   **1.0.0**

    -   Hello, there is nothing new here yet.
